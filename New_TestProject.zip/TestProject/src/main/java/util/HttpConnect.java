package util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;


import entity.JenkinsJob;

public class HttpConnect {
	public static String sendGetRequest(String url, String authorization,JenkinsJob job) {
		URLConnection urlConn = null;
		String crumb="";
		String inputLine	="";
		String Jenkinscrumb="";
		try {
			  URL url1 = new URL(url);
			  urlConn = url1.openConnection(); 
			 // urlConn.setRequestProperty("Authorization","Basic " + authorization);
			  BufferedReader buff = new BufferedReader(new InputStreamReader(urlConn.getInputStream()));
		
			  while ((inputLine = buff.readLine()) != null) 
				  Jenkinscrumb=inputLine.toString();
			  	  System.out.println(Jenkinscrumb);
       
			  	  /*String[] arrOfStr = Jenkinscrumb.split(",", -2); 
			  	  System.out.println(arrOfStr[1]);  
			  	  String crumb1 = arrOfStr[1].substring(1);
			  	  crumb1 = crumb1.split(":")[1];
			  	  System.out.println(crumb1);
			  	  crumb=crumb1.replace("\"","");
			  	  System.out.println(crumb);*/
		   
			  	  //curl -s -XPOST 'http://example.com/createItem?name=yourJobName' -u username:API_TOKEN --data-binary @mylocalconfig.xml -H "Content-Type:text/xml"
         
			  	  //String[] command = {"curl -s -XPOST " +job.getUrl()+"/createItem?name="+job.getJobname()+"-u"+job.getUsername()+":"+ job.getToken() + "--data-binary" + job.getXmlFilePath()+ crumb+  "'content-Type:text/xml'"}; 
			  	  //curl -s -XPOST 'http://129.146.59.178:8080/createItem?name=yourdemo' -u devops:11dc8f66300e9e3550f66f0bb22f1fbf38 --data-binary @mylocalconfig.xml -H a915c770d8bad738c5ce8118d4b2384c8d78bfe52e76b4024ddf2398b256f86a -H "Content-Type:text/xml"
			  	  String command = "curl -s -XPOST '" +job.getUrl()+"/createItem?name="+job.getJobname()+ "' -u " +job.getUsername()+":"+ job.getToken() +  " --data-binary "  + job.getXmlFilePath() + " -H "  +  crumb +   " 'content-Type:text/xml'"; 
			  	  System.out.println(command);
			  	  
			  	  ProcessBuilder process = new ProcessBuilder(command);
			  	  Process p;
			  	  p = process.start();
			  	  BufferedReader reader = new BufferedReader(new InputStreamReader(p.getInputStream()));
			  	  StringBuilder builder = new StringBuilder();
			  	  String line = null;
			  	  while ((line = reader.readLine()) != null) {
			  		  builder.append(line);
			  		  builder.append(System.getProperty("line.separator"));
			  	  }
			  	  String result = builder.toString();
			  	  System.out.print(result);

		} catch (IOException e) {
			System.out.print("error");
			e.printStackTrace();
		}
		return crumb;
}


  public static void uploadCred(JenkinsJob job) {
  
	  try { 
		  String credentials = Authenticator.getAuthToken(job.getUsername(),job.getToken()); 
		  String crumb = HttpConnect.sendGetRequest(job.getUrl()+"/crumbIssuer/api/json",credentials, job);
		  String[] command = {"curl -X POST " + " \\ -U"+ job.getUsername()+":"+
				  	job.getToken() + "\\ -H" + crumb+ "\\ -H"+
				  		"'content-type:application/xml' \\ -d" +job.getUploadCred()+job.getUrl()+
				  		"/job/top-folder/job/sub-folder/credentials/store/folder/domain/_/createCredentials"
		  	};
  
  
		  //curl -X POST \ -u $JENKINS_USER:$JENKINS_PASSWORD_OR_API_TOKEN \ -H "Jenkins-Crumb:${JENKINS_CRUMB}" \ -H 'content-type:application/xml' \ -d @credential.xml \"$JENKINS_URL/job/top-folder/job/sub-folder/credentials/store/folder/domain/_/createCredentials"
		  ProcessBuilder process = new ProcessBuilder(command); 
		  Process p = process.start(); BufferedReader reader = new BufferedReader(new 
				  InputStreamReader(p.getInputStream())); StringBuilder builder = new
				  StringBuilder(); String line = null; while ((line = reader.readLine()) !=
				  null) { builder.append(line);
				  builder.append(System.getProperty("line.separator")); } String result =
						  builder.toString(); System.out.print(result);
  
	  } catch (IOException e) { System.out.print("error"); e.printStackTrace(); }
 
	}
}
