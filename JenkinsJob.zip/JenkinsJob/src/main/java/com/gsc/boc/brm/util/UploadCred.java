package com.gsc.boc.brm.util;

public class UploadCred {
	public static void uploadcredential (String url, String xmlFilePath, String authorization) {

}
}