
public class DisJoint {

	public static void main(String args[]){
		int A[]={1,12,42,70,36,-4,43,15};
		int B[]={5,15,44,72,36,2,69,24};
				
		DisJoint dj = new DisJoint();
		System.out.println("" + dj.solution(A, B, A.length));
	}
	
	int solution(int[] A, int[] B, int N){
		int count=0;
		int i,j;
		boolean found;
		for(i=0; i<N; i++)
		{
			found=false;
			for(j=0; j<N; j++)
			{
				if(i!=j)
				{
					if( A[j]<=A[i] && B[j] >= A[i] && B[j] >=A[i] && B[j] <= B[i])
					{
						found=true;
						System.out.println(A[i]+" "+B[i]+" "+A[j]+" "+B[j]+" <--> " + A[j] + " " + B[i]);
						count+=1;
						break;
											
					}
					else if( ((A[i]<=A[j])&&(A[j]<=B[i])) || ((A[i]<=B[j])&&(B[j]<=B[i])) )
					{
						found=true;
						break;
					}
				}
			}
			
			if(!found)
			{
				System.out.println(A[i] + " " + B[i]);
				
				count+=1;
			}
			
		}
		return count;
	}
}
