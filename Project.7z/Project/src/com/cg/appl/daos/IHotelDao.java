package com.cg.appl.daos;

import java.util.List;

import com.cg.appl.entities.Hotel;
import com.cg.appl.entities.RoomDetails;
import com.cg.appl.entities.Users;
import com.cg.appl.exception.BookingException;


public interface IHotelDao {
	
	boolean isUserAuthenticated(String userName, String password) throws BookingException;
	List<Hotel> showAllHotel() throws BookingException;
	public boolean deleteHotel(String hotel_id) throws BookingException;
	public boolean updateHotel(Hotel hot);
	List<Hotel> GetHotelNames() throws BookingException;
	public boolean deleterooms(String room_id)throws BookingException;
	public String addRoom(RoomDetails room) throws BookingException;
	public String addUser(Users user) throws BookingException;
}
