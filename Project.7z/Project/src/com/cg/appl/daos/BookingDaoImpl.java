package com.cg.appl.daos;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import com.cg.appl.entities.BookingDetails;
import com.cg.appl.entities.Hotel;
import com.cg.appl.entities.RoomDetails;
import com.cg.appl.exception.BookingException;
import com.cg.appl.util.DBUtil;


public class BookingDaoImpl implements BookingDao{

	@Override
	public List<Hotel> showAllHotel() throws BookingException {
		
		return null;
	}

	@Override
	public boolean updateRoom(RoomDetails room) throws BookingException {
		Connection conn = null;
		PreparedStatement pstm = null;

		String Query = "update RoomDetails set room_type=?,per_night_rate=?,availability=? where hotel_id=?";

		try {
			conn = DBUtil.obtainConnection();
			pstm = conn.prepareStatement(Query);
			pstm.setString(1,room.getRoom_type());
			pstm.setInt(2,room.getPer_night_rate());
			pstm.setBoolean(3,room.isAvailability());
			
			
			int i = pstm.executeUpdate();
			if (i == 1) {
				return true;
			} else {
				return false;
			}

		} catch (BookingException | SQLException e) {
			e.printStackTrace();
			try {
				throw new BookingException("problem in update");
			} catch (BookingException e1) {

				e1.printStackTrace();
			}
		} finally {
			if (pstm != null) {
				try {
					pstm.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		return false;

	
	}

	@Override
	public int addbook(BookingDetails book) throws BookingException {
		int empId = getEmployee();
		Connection conn = null;
		PreparedStatement pstm = null;
		int msg = 0;
		String query = "INSERT INTO bookingdetails VALUES(?,?,?,?,?,?,?,?)";

		try {
			conn = DBUtil.obtainConnection();
			pstm = conn.prepareStatement(query);
			pstm.setInt(1, empId);
			pstm.setString(2, book.getBooking_id());
			pstm.setString(3, book.getRoom_id());
			pstm.setDate(4, (Date)book.getBooked_from());
			pstm.setDate(5, (Date)book.getBooked_to());
			pstm.setInt(6, book.getNo_of_adults());
			pstm.setInt(7, book.getNo_of_children());
			pstm.setInt(8, book.getAmount());
			int status = pstm.executeUpdate();
			if (status == 1) {
				msg = empId;
			}
		} catch (BookingException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new BookingException("problem in insert");
		} finally {
			try {
				pstm.close();
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
		System.out.println(msg);

		return msg;
		
	}

}
