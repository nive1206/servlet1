package com.cg.appl.daos;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.appl.entities.Hotel;
import com.cg.appl.entities.RoomDetails;
import com.cg.appl.entities.Users;
import com.cg.appl.exception.BookingException;
import com.cg.appl.util.DBUtil;

public class HotelDaoImpl implements IHotelDao {

	@Override
	public boolean isUserAuthenticated(String userName, String password)
			throws BookingException {

		return false;
	}

	@Override
	public List<Hotel> showAllHotel() throws BookingException {
		Connection connect = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		List<Hotel> hlist = new ArrayList<Hotel>();
		String query = "SELECT HOTEL_NAME, CITY, ADDRESS, AVG_RATE_PER_NIGHT, PHONE_NO1, PHONENO2, RATING, EMAIL, FAX FROM HOTEL";

		try {
			connect = DBUtil.obtainConnection();
			stmt = connect.prepareStatement(query);
			rs = stmt.executeQuery();
			while (rs.next()) {
				Hotel h1 = new Hotel();
				h1.setHotel_name(rs.getString(""));
				h1.setCity(rs.getString("CITY"));
				h1.setAddress(rs.getString("ADDRESS"));
				h1.setAvg_rate_per_night(rs.getInt("AVG_RATE_PER_NIGHT"));
				h1.setPhone_no1(rs.getString("PHONE_NO1"));
				h1.setPhone_no2(rs.getString("PHONE_NO2"));
				h1.setRating(Integer.parseInt(rs.getString("RATING")));
				h1.setEmail(rs.getString("EMAIL"));
				h1.setFax(rs.getString("FAX"));

				hlist.add(h1);
				return hlist;
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw new BookingException("Unable to display hotel details!!");
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (stmt != null) {
					stmt.close();
				}
				if (connect != null) {
					connect.close();
				}
			} catch (SQLException e) {
				throw new BookingException(" JDBC connection closing failed!!");
			}
		}
		return hlist;
	
	}

	@Override
	public boolean deleteHotel(String hotel_id) throws BookingException {

		Connection conn = null;
		PreparedStatement pstm = null;

		String Query = "delete from hotel where hotel_id=?";
		try {
			conn = DBUtil.obtainConnection();
			pstm = conn.prepareStatement(Query);
			pstm.setString(1, hotel_id);

			int i = pstm.executeUpdate();
			if (i == 1) {
				return true;
			} else {
				return false;
			}

		} catch (BookingException | SQLException e) {
			e.printStackTrace();
			try {
				throw new BookingException("problem in delete", e);
			} catch (BookingException e1) {

				e1.printStackTrace();
			}
		} finally {
			if (pstm != null) {
				try {
					pstm.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}

		return false;

	}

	@Override
	public boolean updateHotel(Hotel hot) {
		Connection conn = null;
		PreparedStatement pstm = null;

		String Query = "update Hotel set city=?,hotel_name=?,address=?,description=?,avg_rate_per_night=?,rating=?,email=?,fax=? where hotel_id=?";

		try {
			conn = DBUtil.obtainConnection();
			pstm = conn.prepareStatement(Query);
			pstm.setString(1, hot.getCity());
			pstm.setString(2, hot.getHotel_name());
			pstm.setString(3, hot.getAddress());
			pstm.setString(4, hot.getDescription());
			pstm.setInt(5, hot.getAvg_rate_per_night());
			pstm.setInt(6, hot.getRating());
			pstm.setString(7, hot.getEmail());
			pstm.setString(8, hot.getFax());
			pstm.setString(9, hot.getHotel_id());
			int i = pstm.executeUpdate();
			if (i == 1) {
				return true;
			} else {
				return false;
			}

		} catch (BookingException | SQLException e) {
			e.printStackTrace();
			try {
				throw new BookingException("problem in update");
			} catch (BookingException e1) {

				e1.printStackTrace();
			}
		} finally {
			if (pstm != null) {
				try {
					pstm.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		return false;

	}

	@Override
	public List<Hotel> GetHotelNames() throws BookingException {
		Connection connect = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		List<Hotel> hlist = new ArrayList<Hotel>();
		String query = "SELECT HOTEL_NAME FROM HOTEL";

		try {
			connect = DBUtil.obtainConnection();
			stmt = connect.prepareStatement(query);
			rs = stmt.executeQuery();
			while (rs.next()) {
				Hotel h1 = new Hotel();
				h1.setHotel_name(rs.getString(""));
				
				hlist.add(h1);
				return hlist;
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw new BookingException("Unable to display hotelnames!!");
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (stmt != null) {
					stmt.close();
				}
				if (connect != null) {
					connect.close();
				}
			} catch (SQLException e) {
				throw new BookingException(" JDBC connection closing failed!!");
			}
		}
		return hlist;
	
		
	}

	@Override
	public boolean deleterooms(String room_id) throws BookingException {
		Connection conn = null;
		PreparedStatement pstm = null;

		String Query = "delete from roomdetails where room_id=?";
		try {
			conn = DBUtil.obtainConnection();
			pstm = conn.prepareStatement(Query);
			pstm.setString(1, room_id);

			int i = pstm.executeUpdate();
			if (i == 1) {
				return true;
			} else {
				return false;
			}

		} catch (BookingException | SQLException e) {
			e.printStackTrace();
			try {
				throw new BookingException("problem in delete", e);
			} catch (BookingException e1) {

				e1.printStackTrace();
			}
		} finally {
			if (pstm != null) {
				try {
					pstm.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}

		return false;
		
	}

	@Override
	public String addRoom(RoomDetails room) throws BookingException {
		String room_id = getroomid();
		Connection conn = null;
		PreparedStatement pstm = null;
		String msg = null;
		String query = "INSERT INTO RoomDetails VALUES(?,?,?,?,?,?,?)";

		try {
			conn = DBUtil.obtainConnection();
			pstm = conn.prepareStatement(query);
			pstm.setString(1,room.getHotel_id() );
			pstm.setString(2,room_id );
			pstm.setString(3, room.getRoom_no());
			pstm.setString(4, room.getRoom_type());
			pstm.setInt(5, room.getPer_night_rate());
			pstm.setBoolean(6,room.isAvailability());
			pstm.setBlob(7, room.getPhoto());
			int status = pstm.executeUpdate();
			if (status == 1) {
				msg = room_id;
			}
		} catch (BookingException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new BookingException("problem in insert");
		} finally {
			try {
				pstm.close();
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
		System.out.println(msg);

		return msg;
		
	}
	public String getroomid() throws BookingException {
		String room_id  = null;
		Connection conn = null;
		PreparedStatement pstm = null;
		String Query = "select room_id_seq.nextval from dual";
		try {
			conn = DBUtil.obtainConnection();
			pstm = conn.prepareStatement(Query);
			ResultSet rs = pstm.executeQuery();
			while (rs.next()) {
				room_id = rs.getString(1);
			}
		} catch (BookingException | SQLException e) {
			e.printStackTrace();
			throw new BookingException("problem in insert");
		} finally {
			try {
				pstm.close();
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return room_id;

	}

	@Override
	public String addUser(Users user) throws BookingException {
		String user_id = getuserid();
		Connection conn = null;
		PreparedStatement pstm = null;
		String msg = null;
		String query = "INSERT INTO users VALUES(?,?,?,?,?,?,?,?)";

		try {
			conn = DBUtil.obtainConnection();
			pstm = conn.prepareStatement(query);
			pstm.setString(1, user_id);
			pstm.setString(2, user.getPassword());
			pstm.setString(3, user.getRole());
			pstm.setString(4,user.getUser_name());
			pstm.setInt(5, user.getMobile_no());
			pstm.setInt(6, user.getPhone());
			pstm.setString(7, user.getAddress());
			pstm.setString(8, user.getEmail());
			int status = pstm.executeUpdate();
			if (status == 1) {
				msg = user_id;
			}
		} catch (BookingException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new BookingException("problem in insert");
		} finally {
			try {
				pstm.close();
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
		System.out.println(msg);

		return msg;
		
	}
	
	public String getuserid() throws BookingException {
		String user_id  = null;
		Connection conn = null;
		PreparedStatement pstm = null;
		String Query = "select user_id_seq.nextval from dual";
		try {
			conn = DBUtil.obtainConnection();
			pstm = conn.prepareStatement(Query);
			ResultSet rs = pstm.executeQuery();
			while (rs.next()) {
				user_id = rs.getString(1);
			}
		} catch (BookingException | SQLException e) {
			e.printStackTrace();
			throw new BookingException("problem in insert");
		} finally {
			try {
				pstm.close();
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return user_id;

	}

	

}
