package com.cg.appl.services;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import com.cg.appl.entities.Hotel;
import com.cg.appl.entities.User;
import com.cg.appl.exception.BookingException;
import com.cg.appl.exceptions.UserException;
import com.cg.appl.util.DBUtil;
import com.cg.appl.util.JndiUtil;



public class HotelServicesImpl implements IHotelServices{
	private DBUtil util;
	public HotelServicesImpl(){
		util = new DBUtil(); 
	}
	
	@Override
	public boolean isUserAuthenticated(String userName, String password)
			throws BookingException {
		User user = getUserDetails(userName);
		if (password.equals(user.getPassword())) {
			return true;
		} else {
			return false;
		}
	}

	@Override
	public User getUserDetails(String userName) throws UserException {
		Connection connect = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		String query = "SELECT PASSWORD, USERFNAME FROM USERS WHERE USERNAME=?";
		try {
			connect = JndiUtil.obtainConnection();
			stmt = connect.prepareStatement(query);
			stmt.setString(1, userName);

			rs = stmt.executeQuery();

			if (rs.next()) {
				String password = rs.getString("PASSWORD");
				String fullname = rs.getString("USERFNAME");
				User user = new User(userName, password, fullname);
				System.out.println(user);
				return user;
			} else {
				throw new UserException("Username Wrong!!");
			}
		} catch (SQLException e) {
			throw new UserException("JDBC failed", e);
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (stmt != null) {
					stmt.close();
				}
				if (connect != null) {
					connect.close();
				}
			} catch (SQLException e) {
				throw new UserException(" JDBC connection closing failed!!");
			}
		}
	}

	@Override
	public List<Hotel> showAllHotel() throws BookingException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean deleteHotel(String hotel_id) throws BookingException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean updateHotel(Hotel hot) {
		// TODO Auto-generated method stub
		return false;
	}

}
