package com.gsc.boc.brm.trial;

import java.awt.List;
import java.util.Arrays;
import java.util.Map;

import org.apache.catalina.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.gsc.boc.brm.entity.JenkinsJob;
import com.gsc.boc.brm.entity.TaskSelector;
import com.gsc.boc.brm.util.HttpConnect;

@Controller
public class IndexController {
@Autowired
JenkinsJob job;
TaskSelector task;

@RequestMapping("/")
public String home(Map<String, Object> model) {
    model.put("message", "Welcome to BRM_Pipeline");
    return "index";
}

@RequestMapping("/register")
public String showForm(Model model,User jenkins) {
   // User user = new User();
	//System.out.println("into register");
	java.util.List<String> tasklist = Arrays.asList("BRM_pipeline", "Upload Credential", "Build Job","Brm_monitoring");
     
    model.addAttribute("user", jenkins);
    model.addAttribute("tasklist", tasklist);
     
    return "register";
}









/*
@RequestMapping(value = "/next", method = RequestMethod.GET)  
public String AppUI(@RequestParam("username") String username, @RequestParam("token") String token, @RequestParam("url") String url, @RequestParam("jobname") String jobname, @RequestParam("task") String task,Model model)  
{  
	
	model.addAttribute("username", username);
	model.addAttribute("token", token);
	model.addAttribute("url", url);
	
JenkinsJob job =  new JenkinsJob();

	job.setToken(token);
	job.setUsername(username);
	job.setUrl(url);
	job.setJobname(jobname);
	
	if (task.equals("Build Job"))
	{
		HttpConnect.buildJob(task, job);
	}
	else if (task.equals("BRM_Monitoring"))
	{
		HttpConnect.Monitoring(task, job);
	}


return "next";  
}
*/
}
	    
	    
	