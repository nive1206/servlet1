package com.gsc.boc.brm.entity;


import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

@Component
public class JenkinsJob {
	String username;
	String token;
	String url;
	String xmlFilePath;
	private MultipartFile uploadCred ;
	String propFile;
	String jobname;

	

	public String getPropFile() {
		return propFile;
	}

	public void setPropFile(String propFile2) {
		this.propFile = propFile2;
	}

	
	
	

	public JenkinsJob() {
		super();
		this.username = username;
		this.token = token;
		this.url = url;
		this.xmlFilePath = xmlFilePath;
		this.uploadCred = uploadCred;
		this.propFile = propFile;
		this.jobname = jobname;
	}

	public String getJobname() {
		return jobname;
	}

	public void setJobname(String jobname) {
		this.jobname = jobname;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getXmlFilePath() {
		return xmlFilePath;
	}

	public void setXmlFilePath(String xmlFilePath) {
		this.xmlFilePath = xmlFilePath;
	}
	public MultipartFile getUploadCred() {
		return uploadCred;
	}

	public void setUploadCred(MultipartFile uploadCred) {
		this.uploadCred = uploadCred;
	}
	@Override
	public String toString() {
		return "JenkinsJob [username=" + username + ", token=" + token + ", url=" + url + ", xmlFilePath=" + xmlFilePath
				+ ", uploadCred=" + uploadCred + ", jobname=" + jobname + ", propFile=" + propFile + "]";
	}
}
