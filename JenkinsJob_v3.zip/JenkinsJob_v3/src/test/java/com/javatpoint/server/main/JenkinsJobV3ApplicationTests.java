package com.javatpoint.server.main;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JenkinsJobV3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
