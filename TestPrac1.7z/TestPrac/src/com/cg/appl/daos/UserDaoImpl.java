package com.cg.appl.daos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.naming.NamingException;

import com.cg.appl.Util.Dbutil;
import com.cg.appl.entities.User1;
import com.cg.appl.exception.UserException;


public class UserDaoImpl implements UserDao{

	@Override
	public int addUser(User1 usr) throws UserException, NamingException {
		Connection conn = null;
		PreparedStatement pstm = null;
		int msg = 0;
		String query = "INSERT INTO user123 VALUES(?,?,?,?)";

		try {
			conn = Dbutil.obtainConnection();
			pstm = conn.prepareStatement(query);
			pstm.setString(1, usr.getName());
			pstm.setString(2,usr.getUsername() );
			pstm.setString(3,usr.getPassword());
			pstm.setString(4,usr.getMobno());
			
			int status = pstm.executeUpdate();
			/*if (status == 1) {
				msg = empId;
			}*/
		} catch (UserException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new UserException("problem in insert",e);
		} finally {
			if(pstm!=null){
				try {
					pstm.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}if(conn!=null){
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		//System.out.println(msg);

		return msg;
	
	}

}
