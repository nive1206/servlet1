package com.cg.appl.services;

import javax.naming.NamingException;

import com.cg.appl.daos.UserDao;
import com.cg.appl.daos.UserDaoImpl;
import com.cg.appl.entities.User1;
import com.cg.appl.exception.UserException;

public class UserServiceImpl implements UserService {
UserDao dao;


	public UserServiceImpl() {
	dao=new UserDaoImpl();
}


	@Override
	public int addUser(User1 usr) throws UserException, NamingException {
		// TODO Auto-generated method stub
		return dao.addUser(usr);
	}

}
