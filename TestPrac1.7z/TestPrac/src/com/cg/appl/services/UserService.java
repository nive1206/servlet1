package com.cg.appl.services;

import javax.naming.NamingException;

import com.cg.appl.entities.User1;
import com.cg.appl.exception.UserException;

public interface UserService {
	public int addUser(User1 usr) throws UserException, NamingException;
}
