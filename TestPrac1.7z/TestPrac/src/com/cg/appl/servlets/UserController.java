package com.cg.appl.servlets;

import java.io.IOException;

import javax.naming.NamingException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.appl.entities.Amount;
import com.cg.appl.entities.User1;
import com.cg.appl.exception.UserException;
import com.cg.appl.services.UserService;
import com.cg.appl.services.UserServiceImpl;


@WebServlet("*.do")
public class UserController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private RequestDispatcher requestDispatcher;
	private String nextJspString;
	String msg = null;
	UserService service;

	public UserController() {
		super();
		service = new UserServiceImpl();

	}
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		processRequest(request, response);
	}
	private void processRequest(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		String command = request.getServletPath();

		switch (command) {
		case "/insert.do": {
			
			nextJspString = "/insert.jsp";
			
		}
		break;
		case "/useradd.do":{
			User1 usr=new User1();
			String name = request.getParameter("name");
			String username = request.getParameter("uname");
			String password = request.getParameter("pass");
			String mobileno=request.getParameter("mno");
			
			
			
			
			
			
			//System.out.println(name + "" + qualification);
			usr.setName(name);
			usr.setUsername(username);
			usr.setPassword(password);
			usr.setMobno(mobileno);
		try {
			service.addUser(usr);
		} catch (UserException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NamingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			/*System.out.println(empId);
			request.setAttribute("id", empId);*/
		nextJspString=("/Welcome.jsp");
			//req.forward(request, response);
		}
		break;
		case "/pay.do":{
			Amount amt=new Amount();
			String amount=request.getParameter("amount");
			int amount1=Integer.parseInt(amount);
			amt.setAmountpayed(amount1);
			int remainingamount=750-amount1;
			
				
				//request.setAttribute("book", usr);
				request.setAttribute("amt1", amt);
				request.setAttribute("ra",remainingamount);
				
			nextJspString=("/home.jsp");
				//res.forward(request, response);
			
		}
		break;
		}
		requestDispatcher = request.getRequestDispatcher(nextJspString);
		requestDispatcher.forward(request, response);
		}
}
