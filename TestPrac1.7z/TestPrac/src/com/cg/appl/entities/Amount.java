package com.cg.appl.entities;

public class Amount {
private int amountpayed;

public Amount() {
	super();
}

public Amount(int amountpayed) {
	super();
	this.amountpayed = amountpayed;
}

public int getAmountpayed() {
	return amountpayed;
}

public void setAmountpayed(int amountpayed) {
	this.amountpayed = amountpayed;
}

@Override
public String toString() {
	return "Amount [amountpayed=" + amountpayed + "]";
}

}
