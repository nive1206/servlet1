package com.cg.appl.entities;

public class User1 {
	private String name;
	private String username;
	private String password;
	private String mobno;
	public User1(String name, String username, String password, String mobno) {
		super();
		this.name = name;
		this.username = username;
		this.password = password;
		this.mobno = mobno;
	}
	public User1() {
		super();
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getMobno() {
		return mobno;
	}
	public void setMobno(String mobno) {
		this.mobno = mobno;
	}
	@Override
	public String toString() {
		return "User1 [name=" + name + ", username=" + username + ", password=" + password + ", mobno=" + mobno + "]";
	}
	

}
