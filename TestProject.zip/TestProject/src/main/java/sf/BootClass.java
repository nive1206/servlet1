package sf;

import java.awt.EventQueue;

import ui.AppUI;


public class BootClass {

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			@Override
			public void run() {
				try{
					AppUI attributesWindow = new  AppUI();
					attributesWindow.jFrame.setVisible(true);
				}catch(Exception e){
					e.printStackTrace();
				}
				
			}
		});
	}

}
