package util;

import entity.JenkinsJob;

public class JobBuilder {
	public void createJob(JenkinsJob job){
		// storing username & password in credentials by calling method readCredentials
		//String credentials = Authenticator.readCredentials("C:\\Users\\nusingh\\Desktop\\Jenkins\\config\\credentials.txt");
		//System.out.println(credentials);
		
		String credentials = Authenticator.getAuthToken(job.getUsername(), job.getPassword());
		System.out.println("Credentials read sucessfully from file: " + credentials);
				
		// sending 1st request (get) and storing the crumb value in crumb variable
		String crumb = HttpConnector.sendGetRequest("http://129.146.59.178:8080/crumbIssuer/api/json",credentials);
		System.out.println("Get request processed successfully. crumb value obtained");
				        
		// sending 2nd request (post). passing crumb value and xml file with it
		//HttpConnector.sendPostRequest("http://129.146.59.178:8080/createItem?name=Demo", "C:\\Users\\nusingh\\Desktop\\config.xml", credentials);
		HttpConnector.sendPostRequest(job.getUrl(), job.getXmlFilePath(), credentials);
		System.out.println("Post request processed successfully");
				        
		System.out.println("DONE !!");
	}
}
