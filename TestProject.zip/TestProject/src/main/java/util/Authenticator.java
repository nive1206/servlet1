package util;

import java.io.FileReader;
import java.io.IOException;
import java.util.Base64;
import java.util.Scanner;

public class Authenticator {
	public static String readCredentials(String fileName){
		String authorization = null;
		try{
			FileReader reader=new FileReader("C:\\Users\\e01u\\Desktop\\credentials.txt");
			Scanner in= new Scanner(reader);
	        
	        while (in.hasNextLine()) {
	            String line=in.nextLine();
	            authorization = Base64.getEncoder().encodeToString(line.getBytes());
	            System.out.println(line  + " = " + authorization);
	        }
	        in.close();
	        
	    }catch (IOException exception){
	        System.out.println("Error processing file:" +exception);
	        exception.printStackTrace();
	    }
		return authorization;
    }
	
	public static String getAuthToken(String username, String passwd){
		String authorization = null;
		if(username != null && passwd != null && username!="" && passwd!=""){
			authorization = username+";"+passwd;
			System.out.println(authorization);
			authorization = Base64.getEncoder().encodeToString(authorization.getBytes());
		}
		return authorization;
    }
}
