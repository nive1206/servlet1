package util;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;

import org.apache.http.HttpEntity;
import org.apache.http.HttpHeaders;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.mime.HttpMultipartMode;
import org.apache.http.entity.mime.MultipartEntityBuilder;
import org.apache.http.entity.mime.content.FileBody;
import org.apache.http.impl.client.HttpClientBuilder;


public class HttpConnector {
	
	public static String sendGetRequest(String url, String authorization) {
		URLConnection urlConn = null;
		String crumb = "";
		String inputLine = "";
		String Jenkinscrumb = "";
		try {
			//JSONParser parser = new JSONParser();
			//URL url1 = new URL("http://129.146.59.178:8080/crumbIssuer/api/json");
			URL url1 = new URL(url);
		
			urlConn = url1.openConnection();
			urlConn.setRequestProperty("Authorization", "Basic " + authorization);
			BufferedReader buff = new BufferedReader(new InputStreamReader(urlConn.getInputStream()));
			while ((inputLine = buff.readLine()) != null) 
				Jenkinscrumb=inputLine.toString();
			System.out.println(Jenkinscrumb);
	    
			String[] arrOfStr = Jenkinscrumb.split(",", -2); 
			System.out.println(arrOfStr[1]);  
			String crumb1 = arrOfStr[1].substring(1);
			crumb1 = crumb1.split(":")[1];
			System.out.println(crumb1);
			crumb=crumb1.replace("\"","");
			System.out.println(crumb);
		}catch (IOException e) {
			e.printStackTrace();
		}
		return crumb;
	}
	
	public static void sendPostRequest (String url, String xmlFilePath, String authorization) {
		//Your Code
		/*URLConnection urlConn = null;
	    try{
	        URL url1 = new URL("http://129.146.59.178:8080/createItem?name=Demo");
			HttpURLConnection conn=(HttpURLConnection)url1.openConnection();
			conn.setRequestMethod("POST");
			conn.setRequestProperty("Authorization", "Basic " + authorization);
			
	        File file = new File("C:\\Users\\e01u\\Desktop\\config.xml");
	        MultipartEntity multipartEntity = new MultipartEntity(HttpMultipartMode.STRICT);
	        multipartEntity.addPart("file", (ContentBody) file);
	
	        conn.setRequestProperty("Content-Type", multipartEntity.getContentType().getValue());
	        OutputStream out = conn.getOutputStream();
	        try {
	            multipartEntity.writeTo(out);
	        }catch(Exception e){
	        	e.printStackTrace();
	        }finally {
	            out.close();
	        }
	        int status = conn.getResponseCode();
	
	    }catch(Exception e){
	        e.printStackTrace();
	    }*/
		
		
		//Trying new code
		/*//Creating CloseableHttpClient object
	    CloseableHttpClient httpclient = HttpClients.createDefault();
	    //Creating a file object
	    File file = new File("C:\\Users\\e01u\\Desktop\\config.xml");
	    //Creating the FileBody object
	    FileBody filebody = new FileBody(file, ContentType.DEFAULT_BINARY);
	    //Creating the MultipartEntityBuilder
	    MultipartEntityBuilder entitybuilder = MultipartEntityBuilder.create();
	    //Setting the mode
	    //Also try HttpMultipartMode.BROWSER_COMPATIBLE
	    entitybuilder.setMode(HttpMultipartMode.STRICT);
	    //Adding a file
	    entitybuilder.addPart("Config", filebody);
	    //entitybuilder.addBinaryBody("image", new File("logo.png"));

	    //Building a single entity using the parts
	    HttpEntity mutiPartHttpEntity = entitybuilder.build();
	    //Building the RequestBuilder request object
	    RequestBuilder reqbuilder = RequestBuilder.post();
	    //Set the entity object to the RequestBuilder
	    reqbuilder.setEntity(mutiPartHttpEntity);
	    //Building the request
	    HttpUriRequest multipartRequest = reqbuilder.build();
	    //Executing the request
	    HttpResponse httpresponse;
		try {
			httpresponse = httpclient.execute(multipartRequest);
			//Printing the status and the contents of the response
		    System.out.println(EntityUtils.toString(httpresponse.getEntity()));
		    System.out.println(httpresponse.getStatusLine());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
		
		//OR
		//TRY THIS
		HttpPost request = new HttpPost(url);
		String authHeader = "Basic " + authorization;
		request.setHeader(HttpHeaders.AUTHORIZATION, authHeader);
		
		
		//HttpPost post = new HttpPost(url);
		File file = new File(xmlFilePath);
		FileBody fileBody = new FileBody(file, ContentType.DEFAULT_BINARY);

		MultipartEntityBuilder builder = MultipartEntityBuilder.create();
		builder.setMode(HttpMultipartMode.BROWSER_COMPATIBLE);
		builder.addPart("Config", fileBody);
		HttpEntity entity = builder.build();
		
		request.setEntity(entity);
		//CloseableHttpClient client = HttpClients.createDefault();
		HttpClient client = HttpClientBuilder.create().build();
		try {
			HttpResponse response = client.execute(request);
			System.out.println(response.toString());
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	/*public void test(){
		
		String auth = DEFAULT_USER + ":" + DEFAULT_PASS;
		byte[] encodedAuth = Base64.encodeBase64(
		  auth.getBytes(StandardCharsets.ISO_8859_1));
		String authHeader = "Basic " + new String(encodedAuth);
		//request.setHeader(HttpHeaders.AUTHORIZATION, authHeader);
		 
		HttpClient client = HttpClientBuilder.create().build();
		HttpResponse response = client.execute(request);
		 
		int statusCode = response.getStatusLine().getStatusCode();
		assertThat(statusCode, equalTo(HttpStatus.SC_OK));
	}*/

}
