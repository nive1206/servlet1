package entity;

public class JenkinsJob {
	String username;
	String password;
	String url;
	String xmlFilePath;
	
	public JenkinsJob(){}
	
	public JenkinsJob(String username, String password, String url,
			String xmlFilePath) {
		super();
		this.username = username;
		this.password = password;
		this.url = url;
		this.xmlFilePath = xmlFilePath;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getXmlFilePath() {
		return xmlFilePath;
	}

	public void setXmlFilePath(String xmlFilePath) {
		this.xmlFilePath = xmlFilePath;
	}

	@Override
	public String toString() {
		return "JenkinsJob [username=" + username + ", password=" + password
				+ ", url=" + url + ", xmlFilePath=" + xmlFilePath + "]";
	}
}
