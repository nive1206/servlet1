package com.gsc.boc.brm.entity;

public class TaskSelector {
	String ticketTool;
	String scmTool;
	String buildTool;
	String ciTool;
	String testTool;
	String dockerTool;
	String codescanTool;
	String repoTool;
	String configfilepath;
	String monitorTool;
	public String getMonitorTool() {
		return monitorTool;
	}
	public void setMonitorTool(String monitorTool) {
		this.monitorTool = monitorTool;
	}
	public TaskSelector(String ticketTool, String scmTool, String buildTool, String ciTool, String testTool,
			String dockerTool, String codescanTool, String repoTool, String configfilepath, String monitorTool) {
		super();
		this.ticketTool = ticketTool;
		this.scmTool = scmTool;
		this.buildTool = buildTool;
		this.ciTool = ciTool;
		this.testTool = testTool;
		this.dockerTool = dockerTool;
		this.codescanTool = codescanTool;
		this.repoTool = repoTool;
		this.configfilepath = configfilepath;
		this.monitorTool = monitorTool;
	}
	public TaskSelector(String ticketTool, String scmTool, String buildTool, String ciTool, String testTool,
			String dockerTool, String codescanTool, String repoTool, String configfilepath) {
		super();
		this.ticketTool = ticketTool;
		this.scmTool = scmTool;
		this.buildTool = buildTool;
		this.ciTool = ciTool;
		this.testTool = testTool;
		this.dockerTool = dockerTool;
		this.codescanTool = codescanTool;
		this.repoTool = repoTool;
		this.configfilepath = configfilepath;
	}
	public String getConfigfilepath() {
		return configfilepath;
	}
	public void setConfigfilepath(String configfilepath) {
		this.configfilepath = configfilepath;
	}
	public TaskSelector(String ticketTool, String scmTool, String buildTool, String ciTool, String testTool,
			String dockerTool, String codescanTool, String repoTool) {
		super();
		this.ticketTool = ticketTool;
		this.scmTool = scmTool;
		this.buildTool = buildTool;
		this.ciTool = ciTool;
		this.testTool = testTool;
		this.dockerTool = dockerTool;
		this.codescanTool = codescanTool;
		this.repoTool = repoTool;
	}
	public TaskSelector() {
		super();
		// TODO Auto-generated constructor stub
	}
	public String getTicketTool() {
		return ticketTool;
	}
	public void setTicketTool(String ticketTool) {
		this.ticketTool = ticketTool;
	}
	public String getScmTool() {
		return scmTool;
	}
	public void setScmTool(String scmTool) {
		this.scmTool = scmTool;
	}
	public String getBuildTool() {
		return buildTool;
	}
	public void setBuildTool(String buildTool) {
		this.buildTool = buildTool;
	}
	public String getCiTool() {
		return ciTool;
	}
	public void setCiTool(String ciTool) {
		this.ciTool = ciTool;
	}
	public String getTestTool() {
		return testTool;
	}
	public void setTestTool(String testTool) {
		this.testTool = testTool;
	}
	public String getDockerTool() {
		return dockerTool;
	}
	public void setDockerTool(String dockerTool) {
		this.dockerTool = dockerTool;
	}
	public String getCodescanTool() {
		return codescanTool;
	}
	public void setCodescanTool(String codescanTool) {
		this.codescanTool = codescanTool;
	}
	public String getRepoTool() {
		return repoTool;
	}
	public void setRepoTool(String repoTool) {
		this.repoTool = repoTool;
	}
	@Override
	public String toString() {
		return "TaskSelector [ticketTool=" + ticketTool + ", scmTool=" + scmTool + ", buildTool=" + buildTool
				+ ", ciTool=" + ciTool + ", testTool=" + testTool + ", dockerTool=" + dockerTool + ", codescanTool="
				+ codescanTool + ", repoTool=" + repoTool + ", configfilepath=" + configfilepath + ", monitorTool="
				+ monitorTool + "]";
	}
	
	

}
